from django.contrib import admin
from .models.food import Food
from .models.category import Category
from .models.customer import Customer
from .models.orders import Order
from .models.help import Help

# Register your models here.
class AdminFood(admin.ModelAdmin):
    list_display = ['name', 'price', 'category']


class AdminCategory(admin.ModelAdmin):
    list_display = ['name']





admin.site.register(Food, AdminFood)
admin.site.register(Category, AdminCategory)
admin.site.register(Customer)
admin.site.register(Order)
admin.site.register(Help)