"""FoodMania URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .views.home import Index
from .views.login import Login, logout
from .views.signup import Signup
from .views.cart import Cart
from .views.checkout import Checkout
from .views.orders import OrderView
from .middlewares.auth import AuthMiddleWare
from .views.aboutus import Aboutus
from .views.help import Help_view
from .views.search import Search_view

urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('signup', Signup.as_view(), name='signup'),
    path('login', Login.as_view(), name='login'),
    path('logout', logout , name='logout'),
    path('cart', Cart.as_view() , name='cart'),
    path('checkout',AuthMiddleWare(Checkout.as_view()) , name='checkout'),
    path('order', AuthMiddleWare(OrderView.as_view()) , name='order'),
    path('aboutus', Aboutus.as_view(), name='aboutus'),
    path('help', Help_view.as_view(), name='help'),
    path('search', Search_view.as_view(), name='search'),
]
