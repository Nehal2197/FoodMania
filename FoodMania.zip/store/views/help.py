from django.shortcuts import redirect, render
from django.views import View
from store.models.customer import Customer
from store.models.help import Help

class Help_view(View):
    def get(self, request):
        return render(request, 'help.html')


    def post(self, request):
        name = request.POST.get('name')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        description = request.POST.get('desc')
        value = Help(name=name, phone=phone, email=email, description=description)
        value.getHelp()

        return redirect('help')