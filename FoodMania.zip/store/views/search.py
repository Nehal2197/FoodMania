from django.shortcuts import render
from django.views import View
from store.models.food import Food
from store.models.category import Category

class Search_view(View):
    def get(self, request):
        qur = request.GET.get('search').lower()
        foods = [item for item in Food.objects.all() if qur in item.name.lower() or qur in item.description.lower()]
        return render(request, 'search.html', {'foods': foods})