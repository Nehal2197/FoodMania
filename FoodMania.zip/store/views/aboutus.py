from django.shortcuts import render
from django.views import View

class Aboutus(View):

    def get(self, request):
        return render(request, 'aboutus.html')