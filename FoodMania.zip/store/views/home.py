from django.shortcuts import render, redirect
from django.http import HttpResponse
from store.models.food import Food
from store.models.category import Category
from store.models.customer import Customer
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
# Create your views here.

class Index(View):
    def post(self, request):
        food = request.POST.get('food')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(food)
            if quantity:
                if remove:
                    if quantity<=1:
                        cart.pop(food)
                    else:
                        cart[food] = quantity - 1
                else:
                    cart[food] = quantity + 1

            else:
                cart[food] = 1
        else:
            cart = {}
            cart[food] = 1

        request.session['cart'] = cart
        # print('cart', request.session['cart'])
        return redirect('homepage')



        print(food)
        return redirect('homepage')

    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
            
        foods = None
        categories = Category.get_all_categories()
        categoryID = request.GET.get('category')
        if categoryID:
            foods = Food.get_all_foods_by_categoryid(categoryID)
        else:
            foods = Food.get_all_foods()

        data = {}
        data['foods'] = foods
        data['categories'] = categories
        print('you are :', request.session.get('email'))
        return render(request, 'index.html', data)




